"""API Router Aggregator."""
from fastapi import APIRouter
from app.api.endpoints import health, forensics, cartel, analytics, dashboard, operations, indic

api_router = APIRouter()
api_router.include_router(health.router)
api_router.include_router(forensics.router, prefix="/forensics")
api_router.include_router(cartel.router, prefix="/cartel")
api_router.include_router(analytics.router, prefix="/analytics")
api_router.include_router(dashboard.router, prefix="/dashboard")
api_router.include_router(operations.router, prefix="/operations")
api_router.include_router(indic.router, prefix="/indic", tags=["Sarvam Indic AI"])
